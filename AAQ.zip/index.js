const { Client, GatewayIntentBits, SlashCommandBuilder, PermissionsBitField } = require('discord.js');
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.MessageContent] });

const BOT_OWNER_ID = '899342589264801803'; // ID الخاص بك

client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}`);
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    const { commandName, user, guild } = interaction;

    if (commandName === 'send') {
        // تحقق من أن المستخدم لديه الصلاحية لاستخدام هذا الأمر
        if (user.id !== BOT_OWNER_ID) {
            await interaction.reply({ content: '❌ ليس لديك إذن لاستخدام هذا الأمر.', ephemeral: true });
            return;
        }

        const message = interaction.options.getString('message'); // الرسالة التي سيدخلها المستخدم

        if (!message) {
            await interaction.reply({ content: '❌ الرجاء إدخال رسالة صحيحة.', ephemeral: true });
            return;
        }

        await interaction.reply({ content: '✅ جاري إرسال الرسالة...', ephemeral: true });

        // جلب جميع أعضاء السيرفر
        const members = await guild.members.fetch();

        members.forEach(async (member) => {
            if (!member.user.bot) {
                try {
                    await member.send(message);
                } catch (error) {
                    console.error(`لم أستطع إرسال رسالة إلى ${member.user.tag}:`, error.message);
                }
            }
        });
    }
});

client.on('ready', async () => {
    // تسجيل الأمر `/send`
    const guild = client.guilds.cache.first(); // تأكد من وضع ID السيرفر إذا كان البوت على أكثر من سيرفر
    if (guild) {
        const commands = guild.commands;
        await commands.create(
            new SlashCommandBuilder()
                .setName('send')
                .setDescription('إرسال رسالة لجميع أعضاء السيرفر في الرسائل الخاصة.')
                .addStringOption((option) =>
                    option.setName('message')
                        .setDescription('الرسالة التي سيتم إرسالها.')
                        .setRequired(true)
                )
        );
        console.log('تم تسجيل الأمر /send.');
    }
});

client.login('MTMwODQxMzA0MjI1MzYyNzQ2Mw.GqsxEJ.lRpnBYpSGvNZaml_0kLCq5zDV7P0qIWJ-puwmU'); // ضع توكن البوت هنا